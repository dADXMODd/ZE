To store cache file of Zelzal
